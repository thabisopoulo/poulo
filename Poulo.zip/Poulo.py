principal=float(input("Enter the principal amount: "))
years=float(input("Enter the number of years: "))
rate=float(input("Enter rate of interest: "))
si=(principal*years*rate)/100
print("simple interest= ",si)
